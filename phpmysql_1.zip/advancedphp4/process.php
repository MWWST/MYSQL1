<?php
session_start();
require_once('new-connection.php');





	if(isset($_POST['action']) && $_POST['action'] == 'email') {
	$_SESSION['email'] = $_POST['email'];
	$errors = array();

	if(empty($_POST['email'])) {
		$errors[] = "Please enter a valide email address";
	}

	if(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
	{
		$errors[] = "your email address is bad";
	}

	if (count($errors) > 0)
	{
		$_SESSION['errors'] = $errors;
		header('location: index.php');
		die();
	}

	else {
		$email = escape_this_string($_POST['email']);
		$query="INSERT INTO email_addresses (email) VALUES ('$email')";
		run_mysql_query($query);
		
		if(run_mysql_query($query)){
				$_SESSION['success'] = "Congrats you are good to go! We have added your email to our database";
				header('location: success.php');
				die();
		}
			else {
			$_SESSION['success'] = " UH OH NOT ADDED TO DB";
				}
		header('location: success.php');
		die();	
	}
}
	
?>